import myJson from './translations.json' assert {type: 'json'};
async function enableOtherLang(){
    // loop thru all lang in myjson and disabled = false
    for (var lang in myJson){
        if (document.getElementById(lang.toUpperCase())!=undefined){
            document.getElementById(lang.toUpperCase()).disabled = false
            // document.getElementById(lang.toUpperCase()).value = ''
        }
    }
    // document.getElementsByClassName("dropbtn")[0].value = '';
    // document.getElementById("add").disabled = false
    document.getElementById("highlight").disabled=false
    let translations_json = await getJSON()
    refreshDropDown(translations_json)
}
/* When the user clicks on the button,
toggle between hiding and showing the dropdown content */
function myFunction() {
    document.getElementById("myDropdown").classList.toggle("show");
}
async function getJSON(){
    //purely get json
    new_json = await chrome.storage.local.get(['json']); //await
    if (new_json['json']==undefined || new_json['json']=='undefined'){
        new_json = myJson //checks json is alr populated or not cleared
    }
    else{
        new_json = new_json['json']
    }
    return new_json
}
function refreshDropDown(translations_json_obj){
    let userData = document.getElementsByClassName('dropbtn')[0].value;
    let emptyArray = [];
    let array = translations_json_obj['EN']
    // if dropbtn target value not undefined
    if (userData!=''){
        // look thru keywords in array which is json 
        for (let keyword in array){
            // console.log(array[keyword])
            // if user searched text is in any keyword or regex in json, push it in
            if (array[keyword].toLowerCase().match(new RegExp(userData.toLowerCase())) || (keyword.toLowerCase().match(new RegExp(userData.toLowerCase()))) || array[keyword].toLowerCase().startsWith(userData.toLowerCase())|| keyword.toLowerCase().startsWith(userData.toLowerCase())) {
                emptyArray.push(keyword)
            }
        }
    }
    else{
        // push all keywords into empty array for next operations
        for (let keyword in array){
            emptyArray.push(keyword)
        }
    }
    // refresh dropdown
    document.getElementById("myDropdown").remove()
    var dropdownContent = document.createElement('div');
    dropdownContent.className = 'dropdown-content';
    dropdownContent.id = 'myDropdown';
    document.getElementsByClassName("EN-select-dropdown")[0].appendChild(dropdownContent);
    for (let entry in emptyArray){
        // console.log(emptyArray[entry])
        var a = document.createElement("a");
        a.innerHTML = emptyArray[entry]
        a.className = new_json['EN'][emptyArray[entry]]
        a.addEventListener('click',populate)
        document.getElementsByClassName('dropdown-content')[0].appendChild(a);
    }
}
function populate(){
    // populating the language fields
    // Global variable
    en_keyword = this.innerHTML;
    document.getElementById('key-name').innerHTML = en_keyword
    document.getElementsByClassName("dropbtn")[0].value = new_json['EN'][en_keyword];
    // add keyword field to become empty
    // document.getElementById("find-keyword").value = ''
    //replace value of fields with appropriate value
    for (var lang in new_json){
        if (document.getElementById(lang.toUpperCase()) == null){
            continue
        }
        else{
            var a = document.createElement("a");
            a.innerHTML = lang  
            document.getElementById(lang.toUpperCase()).value = new_json[lang.toUpperCase()][en_keyword];
            document.getElementById(lang.toUpperCase()).disabled = false;
            document.getElementById(lang.toUpperCase()).style.color = 'black';
            if (new_json[lang.toUpperCase()][en_keyword] == undefined){
                document.getElementById(lang.toUpperCase()).value = 'undefined';
                document.getElementById(lang.toUpperCase()).style.color = '#888';
            }
        }
    }
    // disable / enable buttons
    document.getElementById("delete").disabled = false
    document.getElementById("highlight").disabled = false;
    document.getElementById("add").disabled = true;
    document.getElementById("update").disabled = false;
}
function highlight(){
    // retrieve keyword to test and highlight them
    var testingkeyword = document.getElementsByClassName('dropbtn')[0].value
    if (testingkeyword=='' || testingkeyword==null){
        alert("Do not highlight based on empty space! This will break the stripo page!")
    }
    // send message with selection param to get html back
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        chrome.tabs.sendMessage(tabs[0].id, {selection: "test"}, function(response) {
            if (response == undefined){
                alert("Error, extension not able to communicate with webpage. Refresh and try again!");
            }
            else{
                //html code from contentscript/stripo page
                let result = response.html; 
                //testing keyword is in str form
                testingkeyword = new RegExp(testingkeyword,'igs'); 
                // $& is the matched text
                var replacement = '<span style="background-color:#FFFF00; padding:5px">$&</span>'
                result = response.html.replace(testingkeyword,replacement);   
                // Global state variable to track state of tool
                state_testing = true
                // send message with highlighted html and param testing set to true
                chrome.tabs.query({active: true, currentWindow: true}, async function(tabs) {
                    chrome.tabs.sendMessage(tabs[0].id, {html: String(result),testing: true}, function(response) {});
                });
                // enable clear button
                document.getElementById('clear').disabled = false
            }
        });
    });
}
function clearHighlight(){
    // send message with html and testing param -> false means revert back to original
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        chrome.tabs.sendMessage(tabs[0].id, {html: '',testing: false}, function(response) {
            // console.log(response.farewell)
            console.log(response)
            // change state back to false and disable clear button
            if (state_testing==true){
                state_testing = false
                document.getElementById("clear").disabled = true
            }
        });
    });
}

function updateJSON(trans_json){
    // given the translation_json, update the translation_json with the values and set 
    let changed = false;
    let message =`WARNING!!
Please confirm that you want to UPDATE the following 
FROM:
    "EN": {
        "${en_keyword}" : "${trans_json['EN'][en_keyword]}"
    }
TO:
    "EN": {
        "${en_keyword}" : "${document.getElementsByClassName('dropbtn')[0].value}"
    }`
    if (trans_json['EN'][en_keyword] != document.getElementsByClassName('dropbtn')[0].value){
        if (confirm(message)){
            changed = true;
            trans_json['EN'][en_keyword] = document.getElementsByClassName('dropbtn')[0].value}
    }
    
    for (var lang in trans_json){
        if (document.getElementById(lang.toUpperCase()) != undefined){
            // no changes
            // json = undefined, doc = undefined
            // json = smt, doc = smt

            // changes to be made
            // json = smt, doc = smt else
            // json = undefined, doc = smt

            // if json entry == document entry OR (json entry == undefined AND document entry matches 'undefined') then do nth
            if (trans_json[lang.toUpperCase()][en_keyword] == document.getElementById(lang.toUpperCase()).value || (trans_json[lang.toUpperCase()][en_keyword]==undefined && document.getElementById(lang.toUpperCase()).value.match(new RegExp('undefined'),'gi'))){}
            //else means changes to be made
            else{
                if (confirm(`WARNING!!
Please confirm that you want to UPDATE the following 
FROM:
    "${lang.toUpperCase()}": {
        "${en_keyword}" : "${trans_json[lang.toUpperCase()][en_keyword]}"
    }
TO:
    "${lang.toUpperCase()}": {
        "${en_keyword}" : "${document.getElementById(lang.toUpperCase()).value}"
    }`)){
                    changed = true;
                    trans_json[lang.toUpperCase()][en_keyword] = document.getElementById(lang.toUpperCase()).value
                }
            }
        }
    }
    // set translations_json into the local storage
    chrome.storage.local.set({'json':trans_json}, function(){
        console.log("setting");
        console.log(trans_json);
    });
    // show alert success (need to reload anot?)->nope
    if (changed==true){
        alert("Success!");
        // reset the input fields
        reset()
    }
    else{
        alert('Nothing has been changed.')
    }
}
async function deleteJSON(translation_json){
    // delete the entry in json based on the selected entry
    if (confirm(`WARNING\nYou are deleting EN keyword: ${en_keyword}
"EN" : {
    ${en_keyword} : ...
},
"DE" : {
    ${en_keyword} : ...
},
"IT" : {
    ${en_keyword} : ...
}, ... `)){
        for (var lang in translation_json){
            // find the relevant lang and delete
            if (document.getElementById(lang.toUpperCase())!=undefined){
                delete translation_json[lang][en_keyword]
            }
        }
        // delete the EN keyword
        delete translation_json['EN'][en_keyword]
        // set the new json in local storage
        chrome.storage.local.set({'json':translation_json}, function(){
            console.log("setting");
            console.log(translation_json);
        });
        alert("Success!");
    }
}
function reset(){
    // reset entire form
    var iterate = document.getElementsByTagName('input');
    for (var item in iterate){
        if (typeof iterate[item] != 'object'){
            continue
        }
        console.log(iterate[item])
        iterate[item].value = ''
        if (iterate[item].className == 'dropbtn'){
            continue
        }
        iterate[item].disabled = true;
        iterate[item].style.color = 'black'
    }
    // reset the buttons 
    document.getElementById("highlight").disabled = true
    document.getElementById("delete").disabled = true;
    document.getElementById("update").disabled = true;
    document.getElementById("add").disabled = true;
    document.getElementById('key-name').innerHTML = ''
}
function addkeyword(translation_json){
    var added = false
    var name = prompt('Please choose a name for the new entry:\nCannot have whitespace!')
    if (!name || name.match(new RegExp('\\s','g') || translation_json['EN'][name])){
        alert('Unable to proceed without a proper name!')
        return
    }
    var regex = document.getElementsByClassName("dropbtn")[0].value
    var input_fields = document.getElementsByTagName("input");
    //insert en into json
    // console.log(en_keyword)
    // console.log(translation_json['EN'])
    // console.log(translation_json['EN'][en_keyword])
    if (confirm(`Confirm that you want to ADD
    "EN" : {
        ... ,
        ${name} : ${regex}
    }`)){
        added = true
    }
    for (let index = 1; index < input_fields.length; index++) {
        if (input_fields[index].value == ''){
            continue
        }
        console.log(input_fields[index])
        translation_json[input_fields[index].id.toUpperCase()][name] = input_fields[index].value
        console.log(translation_json[input_fields[index].id.toUpperCase()][name])
    }
    if (added==true){
        translation_json['EN'][name] = regex
        alert("Entries have been added! Remember to export and update json file after additions/updates!")
        // set in local storage
        chrome.storage.local.set({'json':translation_json}, function(){
            console.log("setting");
            console.log(translation_json);
        });
        // reset all fields
        reset();
    }
    else{
        alert('Nothing has been added')
    }
    // refresh dropdown
    refreshDropDown(translation_json);
    
}
async function onStartUp(){
    let translation_json = await getJSON()
    refreshDropDown(translation_json)
}

// runtime
onStartUp()
// declaring global variable
let new_json = {}
let en_keyword = ''
let state_testing = false
// creating lines to show connections
$(document).ready(function() {
    $('.EN-div').connections({to:'.block'});
});
// // adding listeners
// document.getElementById("find-keyword").addEventListener("input",enableOtherLang)
document.getElementsByClassName("dropbtn")[0].addEventListener("click",async ()=>{
    let translation_json = await getJSON()
    refreshDropDown(translation_json)
    myFunction()
})
document.getElementById("highlight").addEventListener("click",highlight)
document.getElementById("update").addEventListener("click",async ()=>{
    let json_obj = await getJSON()
    updateJSON(json_obj)
})
document.getElementById("delete").addEventListener("click", async ()=>{
    let json_obj = await getJSON()
    deleteJSON(json_obj)
    json_obj = await getJSON()
    // refresh dropdown with new json
    refreshDropDown(json_obj)
    // reset all the fields
    reset()
})
document.getElementById("add").addEventListener("click", async ()=>{
    let translation_json = await getJSON();
    addkeyword(translation_json);
})
document.getElementById("clear").addEventListener("click",clearHighlight)
// Close the dropdown menu if the user clicks outside of it
window.onclick = function(event) {
    if (!event.target.matches('.dropbtn')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
        var openDropdown = dropdowns[i];
        if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
        }
    }
    }
}
// control the dropbtn dropdown
document.querySelector('.dropbtn').onkeyup = async (e)=>{
    document.getElementById('highlight').disabled = false
    var regexvalue = ''
    if (e.target.value==''){
        reset()
    }
    else{
        // add if type
        // update if select
        // update/add if edit
        enableOtherLang()
        regexvalue = await getJSON()
        regexvalue = regexvalue['EN'][en_keyword]
        if (e.target.value!=regexvalue){
            document.getElementById('update').disabled = false
            document.getElementById('add').disabled = false
        }
        // if no change then purely update
        else{
            document.getElementById('add').disabled = true
        }
    }
    // getJSON
    let new_json = await getJSON()
    refreshDropDown(new_json)
    // keep dropdown open
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
        var openDropdown = dropdowns[i];
        openDropdown.classList.add('show');
    }
}