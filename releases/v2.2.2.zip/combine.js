import myJson from './translations.json' assert {type: 'json'};
function enableOtherLang(){
    // loop thru all lang in myjson and disabled = false
    for (var lang in myJson){
        if (document.getElementById(lang.toUpperCase())!=undefined){
            document.getElementById(lang.toUpperCase()).disabled = false
            document.getElementById(lang.toUpperCase()).value = ''
        }
    }
    document.getElementsByClassName("dropbtn")[0].value = '';
    document.getElementById("delete").disabled = true
    document.getElementById("add").disabled = false
    document.getElementById("update").disabled = true
    document.getElementById("highlight").disabled=false
    getJSON()
}
/* When the user clicks on the button,
toggle between hiding and showing the dropdown content */
function myFunction() {
    document.getElementById("myDropdown").classList.toggle("show");
}
async function getJSON(){
    new_json = await chrome.storage.local.get(['json']); //await
    // console.log(new_json);
    if (new_json['json']==undefined || new_json['json']=='undefined'){
        new_json = myJson //checks json is alr populated or not cleared
    }
    else{
        new_json = new_json['json']
    }
    document.getElementById("myDropdown").remove()
    var dropdownContent = document.createElement('div');
    dropdownContent.className = 'dropdown-content';
    dropdownContent.id = 'myDropdown';
    document.getElementsByClassName("EN-select-dropdown")[0].appendChild(dropdownContent);
    for (var keyword in new_json['EN']){
        var a = document.createElement("a");
        a.innerHTML = keyword;
        a.className = new_json['EN'][keyword]
        // var x = document.createElement('span')
        // x.innerHTML = a.className
        // x.style.display = 'block'
        // x.style.fontSize = 'smaller'
        // a.appendChild(x)
        a.addEventListener("click",populate)
        document.getElementsByClassName("dropdown-content")[0].appendChild(a);
    }
}
function populate(){
    en_keyword = this.innerHTML;
    document.getElementById("delete").disabled = false
    document.getElementsByClassName("dropbtn")[0].value = new_json['EN'][en_keyword];
    document.getElementById("find-keyword").value = ''
    for (var lang in new_json){
        if (document.getElementById(lang.toUpperCase()) == null){
            continue
        }
        else{
            var a = document.createElement("a");
            a.innerHTML = lang  
            document.getElementById(lang.toUpperCase()).value = new_json[lang.toUpperCase()][en_keyword];
            document.getElementById(lang.toUpperCase()).disabled = true;
            if (new_json[lang.toUpperCase()][en_keyword] != undefined){
                document.getElementById(lang.toUpperCase()).disabled = false;
            }
        }
    }
    document.getElementById("highlight").disabled = false;
    document.getElementById("add").disabled = true;
    document.getElementById("update").disabled = false;
}
function highlight(){
    var testingkeyword = document.getElementById("find-keyword").value || myJson['EN'][en_keyword]
    console.log(testingkeyword)
    // chrome.runtime.onConnect.addListener(function(port) {
    //     console.assert(port.name === "knockknock");
    //     port.onMessage.addListener(function(msg) {
    //     //   alert("in port")
    //     });
    //   });
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        chrome.tabs.sendMessage(tabs[0].id, {selection: "test"}, function(response) {
            if (response == undefined){
                alert("Error, extension not able to communicate with webpage. Refresh and try again!");
            }
            else{
                let result = response.html; //html code from contentscript/stripo page
                // chrome.storage.local.set({'en':result}, function(){
                //     console.log("setting en in localstorage"); //set the en html into local storage for UNDO function
                // });
                // document.getElementById("undo").disabled=false; //enable undo for them
                testingkeyword = new RegExp(testingkeyword,'igs'); //testing keyword is in str form
                var replacement = '<span style="background-color:#FFFF00; padding:5px">$&</span>'
                result = response.html.replace(testingkeyword,replacement);   
                console.log(result);
                state_testing = true
                chrome.tabs.query({active: true, currentWindow: true}, async function(tabs) {
                    chrome.tabs.sendMessage(tabs[0].id, {html: String(result),testing: true}, function(response) { //send message when button pressed
                        console.log(response.farewell);
                });
                });
                document.getElementById('clear').disabled = false
            }
        });
    });
}
function clearHighlight(){
    // alert('in clear highlight')
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        chrome.tabs.sendMessage(tabs[0].id, {selection: "test"}, function(response) {
            if (response == undefined){
                alert("Error, extension not able to communicate with webpage. Refresh and try again!");
            }
            else{
                if (state_testing==true){
                    state_testing = false
                    chrome.tabs.query({active: true, currentWindow: true}, async function(tabs) {
                        chrome.tabs.sendMessage(tabs[0].id, {html: '',testing: false}, function(response) { //send message when button pressed
                            console.log(response.farewell);
                    });
                    });
                    // alert('sending msg')
                    document.getElementById("clear").disabled = true
                }
                else{
                    // alert('in else')
                }
                
            }
        });
    });
}

async function updateJSON(){
    new_json = await chrome.storage.local.get(['json']); //await
    console.log(new_json);
    if (new_json['json']==undefined || new_json['json']=='undefined'){
        new_json = myJson //checks json is alr populated or not cleared
    }
    else{
        new_json = new_json['json']
    }
    for (var lang in new_json){
        if (document.getElementById(lang.toUpperCase()) != undefined){
            // if newjson entry != input value
            if (new_json[lang.toUpperCase()][en_keyword] != document.getElementById(lang.toUpperCase()).value && new_json[lang.toUpperCase()][en_keyword]!=undefined){
                if (confirm(`WARNING\nYou are changing ${lang.toUpperCase()}'s ${new_json[lang.toUpperCase()][en_keyword]} to ${document.getElementById(lang.toUpperCase()).value}.\nPlease confirm this is what you want.`)){
                    new_json[lang.toUpperCase()][en_keyword] = document.getElementById(lang.toUpperCase()).value
                }
            }
        }
    }
    chrome.storage.local.set({'json':new_json}, function(){
        console.log("setting");
        console.log(new_json);
    });
    chrome.storage.local.get(['json'],function(result){
        console.log(result['json']);
    });

    //show alert success (need to reload anot?)->nope
    alert("Success!");
    reset()
}
async function deleteJSON(){
    new_json = await chrome.storage.local.get(['json']); //await
    console.log(new_json);
    if (new_json['json']==undefined || new_json['json']=='undefined'){
        new_json = myJson //checks json is alr populated or not cleared
    }
    else{
        new_json = new_json['json']
    }
    if (confirm(`WARNING\nYou are deleting EN keyword: ${en_keyword}`)){
        for (var lang in new_json){
            if (document.getElementById(lang.toUpperCase())!=undefined){
                delete new_json[lang][en_keyword]
            }
        }
        delete new_json['EN'][en_keyword]
        chrome.storage.local.set({'json':new_json}, function(){
            console.log("setting");
            console.log(new_json);
        });
        await getJSON()
        alert("Success!");
        reset();
    }
    
}
function reset(){
    var iterate = document.getElementsByTagName('input');
    console.log(iterate)
    for (var item in iterate){
        // console.log(item)
        // console.log(iterate[item])
        // console.log(typeof iterate[item])
        if (typeof iterate[item] != 'object'){
            continue
        }
        console.log(iterate[item])
        iterate[item].value = ''
        if (iterate[item].id=='find-keyword' || iterate[item].className == 'dropbtn'){
            continue
        }
        iterate[item].disabled = true;
    }
    document.getElementById("highlight").disabled = true
    document.getElementById("delete").disabled = true;
    document.getElementById("update").disabled = true;
    document.getElementById("add").disabled = true;
    document.getElementsByClassName("dropbtn")[0].value = ''
}
function addkeyword(){
    // key and value will be the same for en
    var en_keyword = document.getElementById("find-keyword").value
    var input_fields = document.getElementsByTagName("input");
    //insert en into json
    chrome.storage.local.get(['json'],async function(r){ //need to account for new json
        let new_json = r['json'];
        console.log("in addkeyword")
        console.log(new_json)
        if(new_json == undefined || new_json=='undefined'){
            new_json = myJson
        }
        console.log(new_json['EN'][en_keyword])
        new_json['EN'][en_keyword] = en_keyword
        console.log(new_json)
        //insert other lang into json
        for (let index = 1; index < input_fields.length; index++) {
            if (input_fields[index].value == ''){
                continue
            }
            new_json[input_fields[index].id.toUpperCase()][en_keyword] = input_fields[index].value
            console.log(new_json[input_fields[index].id.toUpperCase()][en_keyword])
        }
        //write back to json
        //BIG ISSUE, need a way to write back to JSON -> where is it stored?
        //write to local storage -> means that next read must be from local storage -> also means need to regulate
        chrome.storage.local.set({'json':new_json}, function(){
            console.log("setting");
            console.log(new_json);
        });
        chrome.storage.local.get(['json'],function(result){
            console.log(result['json']);
        });
        await getJSON()
        //show alert success (need to reload anot?)->nope
        alert("Success!");
        reset()
    });
}

//runtime
let new_json = {}
let en_keyword = ''
let state_testing = false
$(document).ready(function() {
    $('.EN-div').connections({to:'.block'});
});
document.getElementById("find-keyword").addEventListener("input",enableOtherLang)
document.getElementsByClassName("dropbtn")[0].addEventListener("click",myFunction)
document.getElementById("highlight").addEventListener("click",highlight)
document.getElementById("update").addEventListener("click",updateJSON)
document.getElementById("delete").addEventListener("click",deleteJSON)
document.getElementById("add").addEventListener("click",addkeyword)
document.getElementById("clear").addEventListener("click",clearHighlight)
// chrome.runtime.onSuspend.addListener(clearHighlight)
// chrome.runtime.onSuspendCanceled.addListener(clearHighlight)
// Close the dropdown menu if the user clicks outside of it
window.onclick = function(event) {
    if (!event.target.matches('.dropbtn')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
        var openDropdown = dropdowns[i];
        if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
        }
    }
    }
}
getJSON()
document.querySelector('.dropbtn').onkeyup = async (e)=>{
    var inputs = document.getElementsByTagName('input')
    for (var i in inputs){
        if (typeof inputs[i] != 'object'|| inputs[i].className == 'dropbtn'){
            continue
        }
        inputs[i].value = ''
        if (inputs[i].id=='find-keyword' ){
            continue
        }
        inputs[i].disabled = true;
    }
    new_json = await chrome.storage.local.get(['json']); //await
    // console.log(new_json);
    if (new_json['json']==undefined || new_json['json']=='undefined'){
        new_json = myJson //checks json is alr populated or not cleared
    }
    else{
        new_json = new_json['json']
    }
    let userData = e.target.value;
    let emptyArray = [];
    let array = new_json['EN']
    if (userData){
        for (let keyword in array){
            console.log(array[keyword])
            if (array[keyword].toLowerCase().match(new RegExp(userData.toLowerCase())) || (keyword.toLowerCase().match(new RegExp(userData.toLowerCase())))){
                emptyArray.push(keyword)
            }
        }
        console.log(emptyArray)
        
        document.getElementById("myDropdown").remove()
        var dropdownContent = document.createElement('div');
        dropdownContent.className = 'dropdown-content';
        dropdownContent.id = 'myDropdown';
        document.getElementsByClassName("EN-select-dropdown")[0].appendChild(dropdownContent);

        for (let entry in emptyArray){
            console.log(emptyArray[entry])
            var a = document.createElement("a");
            a.innerHTML = emptyArray[entry]
            a.className = new_json['EN'][emptyArray[entry]]
            a.addEventListener('click',populate)
            document.getElementsByClassName('dropdown-content')[0].appendChild(a);
        }
    }
    else{
        getJSON()
    }
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
        var openDropdown = dropdowns[i];
        openDropdown.classList.add('show');
    }
}