import myJson from './translations.json' assert {type: 'json'};
function enableOtherLang(){
    // loop thru all lang in myjson and disabled = false
    for (var lang in myJson){
        if (document.getElementById(lang.toUpperCase())!=undefined){
            document.getElementById(lang.toUpperCase()).disabled = false
            document.getElementById(lang.toUpperCase()).value = ''
        }
    }
    document.getElementsByClassName("dropbtn")[0].innerHTML = 'Select EN Keyword';
    document.getElementById("delete").disabled = true
    document.getElementById("add").disabled = false
    document.getElementById("update").disabled = true
    document.getElementById("highlight").disabled=false
}
/* When the user clicks on the button,
toggle between hiding and showing the dropdown content */
function myFunction() {
    document.getElementById("myDropdown").classList.toggle("show");
}
async function getJSON(){
    new_json = await chrome.storage.local.get(['json']); //await
    console.log(new_json);
    if (new_json['json']==undefined || new_json['json']=='undefined'){
        new_json = myJson //checks json is alr populated or not cleared
    }
    else{
        new_json = new_json['json']
    }
    document.getElementById("myDropdown").remove()
    var dropdownContent = document.createElement('div');
    dropdownContent.className = 'dropdown-content';
    dropdownContent.id = 'myDropdown';
    document.getElementsByClassName("EN-select-dropdown")[0].appendChild(dropdownContent);
    for (var keyword in new_json['EN']){
        var a = document.createElement("a");
        a.innerHTML = new_json['EN'][keyword];
        a.className = keyword
        a.addEventListener("click",populate)
        document.getElementsByClassName("dropdown-content")[0].appendChild(a);
    }
}
function populate(){
    en_keyword = this.className;
    document.getElementById("delete").disabled = false
    document.getElementsByClassName("dropbtn")[0].innerHTML = en_keyword;
    document.getElementById("find-keyword").value = ''
    for (var lang in new_json){
        if (document.getElementById(lang.toUpperCase()) == null){
            continue
        }
        else{
            var a = document.createElement("a");
            a.innerHTML = lang  
            document.getElementById(lang.toUpperCase()).value = new_json[lang.toUpperCase()][en_keyword];
            document.getElementById(lang.toUpperCase()).disabled = true;
            if (new_json[lang.toUpperCase()][en_keyword] != undefined){
                document.getElementById(lang.toUpperCase()).disabled = false;
            }
        }
    }
    document.getElementById("highlight").disabled = false;
    document.getElementById("add").disabled = true;
    document.getElementById("update").disabled = false;
}
function highlight(){
    var testingkeyword = document.getElementById("find-keyword").value || myJson['EN'][en_keyword]
    console.log(testingkeyword)
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        chrome.tabs.sendMessage(tabs[0].id, {selection: "test"}, function(response) {
            if (response == undefined){
                alert("Error, extension not able to communicate with webpage. Refresh and try again!");
            }
            else{
                let result = response.html; //html code from contentscript/stripo page
                // chrome.storage.local.set({'en':result}, function(){
                //     console.log("setting en in localstorage"); //set the en html into local storage for UNDO function
                // });
                // document.getElementById("undo").disabled=false; //enable undo for them
                testingkeyword = new RegExp(testingkeyword,'igs'); //testing keyword is in str form
                var replacement = '<span style="background-color:#FFFF00; padding:5px">$&</span>'
                result = response.html.replace(testingkeyword,replacement);   
                console.log(result);
                chrome.tabs.query({active: true, currentWindow: true}, async function(tabs) {
                    
                    chrome.tabs.sendMessage(tabs[0].id, {html: String(result),testing: true}, function(response) { //send message when button pressed
                        console.log(response.farewell);
                });
                });
            }
        });
    });
}
async function updateJSON(){
    new_json = await chrome.storage.local.get(['json']); //await
    console.log(new_json);
    if (new_json['json']==undefined || new_json['json']=='undefined'){
        new_json = myJson //checks json is alr populated or not cleared
    }
    else{
        new_json = new_json['json']
    }
    for (var lang in new_json){
        if (document.getElementById(lang.toUpperCase()) != undefined){
            if (new_json[lang.toUpperCase()][document.getElementsByClassName("dropbtn")[0].innerHTML] != document.getElementById(lang.toUpperCase()).value && new_json[lang.toUpperCase()][document.getElementsByClassName("dropbtn")[0].innerHTML]!=undefined){
                if (confirm(`WARNING\nYou are changing ${lang.toUpperCase()}'s ${new_json[lang.toUpperCase()][document.getElementsByClassName("dropbtn")[0].innerHTML]} to ${document.getElementById(lang.toUpperCase()).value}.\nPlease confirm this is what you want.`)){
                    new_json[lang.toUpperCase()][document.getElementsByClassName("dropbtn")[0].innerHTML] = document.getElementById(lang.toUpperCase()).value
                }
            }
        }
    }
    chrome.storage.local.set({'json':new_json}, function(){
        console.log("setting");
        console.log(new_json);
    });
    chrome.storage.local.get(['json'],function(result){
        console.log(result['json']);
    });

    //show alert success (need to reload anot?)->nope
    alert("Success!");
    reset()
}
async function deleteJSON(){
    new_json = await chrome.storage.local.get(['json']); //await
    console.log(new_json);
    if (new_json['json']==undefined || new_json['json']=='undefined'){
        new_json = myJson //checks json is alr populated or not cleared
    }
    else{
        new_json = new_json['json']
    }
    if (confirm(`WARNING\nYou are deleting EN keyword: ${document.getElementsByClassName("dropbtn")[0].innerHTML}`)){
        for (var lang in new_json){
            if (document.getElementById(lang.toUpperCase())!=undefined){
                delete new_json[lang][document.getElementsByClassName("dropbtn")[0].innerHTML]
            }
        }
        delete new_json['EN'][document.getElementsByClassName("dropbtn")[0].innerHTML]
        chrome.storage.local.set({'json':new_json}, function(){
            console.log("setting");
            console.log(new_json);
        });
        await getJSON()
        alert("Success!");
        reset();
    }
    
}
function reset(){
    var iterate = document.getElementsByTagName('input');
    console.log(iterate)
    for (var item in iterate){
        // console.log(item)
        // console.log(iterate[item])
        // console.log(typeof iterate[item])
        if (typeof iterate[item] != 'object'){
            continue
        }
        console.log(iterate[item])
        iterate[item].value = ''
        if (iterate[item].id=='find-keyword'){
            continue
        }
        iterate[item].disabled = true;
    }
    document.getElementById("highlight").disabled = true
    document.getElementById("delete").disabled = true;
    document.getElementById("update").disabled = true;
    document.getElementById("add").disabled = true;
    document.getElementsByClassName("dropbtn")[0].innerHTML = 'Select EN Keyword'
}
function addkeyword(){
    // key and value will be the same for en
    var en_keyword = document.getElementById("find-keyword").value
    var input_fields = document.getElementsByTagName("input");
    //insert en into json
    chrome.storage.local.get(['json'],async function(r){ //need to account for new json
        let new_json = r['json'];
        console.log("in addkeyword")
        console.log(new_json)
        if(new_json == undefined || new_json=='undefined'){
            new_json = myJson
        }
        console.log(new_json['EN'][en_keyword])
        new_json['EN'][en_keyword] = en_keyword
        console.log(new_json)
        //insert other lang into json
        for (let index = 1; index < input_fields.length; index++) {
            if (input_fields[index].value == ''){
                continue
            }
            new_json[input_fields[index].id.toUpperCase()][en_keyword] = input_fields[index].value
            console.log(new_json[input_fields[index].id.toUpperCase()][en_keyword])
        }
        //write back to json
        //BIG ISSUE, need a way to write back to JSON -> where is it stored?
        //write to local storage -> means that next read must be from local storage -> also means need to regulate
        chrome.storage.local.set({'json':new_json}, function(){
            console.log("setting");
            console.log(new_json);
        });
        chrome.storage.local.get(['json'],function(result){
            console.log(result['json']);
        });
        await getJSON()
        //show alert success (need to reload anot?)->nope
        alert("Success!");
        reset()
    });
}

//runtime
let new_json = {}
let en_keyword = ''
$(document).ready(function() {
    $('.EN-div').connections({to:'.block'});
});
document.getElementById("find-keyword").addEventListener("input",enableOtherLang)
document.getElementsByClassName("dropbtn")[0].addEventListener("click",myFunction)
document.getElementById("highlight").addEventListener("click",highlight)
document.getElementById("update").addEventListener("click",updateJSON)
document.getElementById("delete").addEventListener("click",deleteJSON)
document.getElementById("add").addEventListener("click",addkeyword)
// Close the dropdown menu if the user clicks outside of it
window.onclick = function(event) {
    if (!event.target.matches('.dropbtn')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
        var openDropdown = dropdowns[i];
        if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
        }
    }
    }
}
getJSON()