import myJson from './translations.json' assert {type: 'json'};
async function getJSON(){
    new_json = await chrome.storage.local.get(['json']); //await
    console.log(new_json);
    if (new_json['json']==undefined || new_json['json']=='undefined'){
        new_json = myJson //checks json is alr populated or not cleared
    }
    else{
        new_json = new_json['json']
    }
    for (var keyword in new_json['EN']){
        var a = document.createElement("a");
        a.innerHTML = new_json['EN'][keyword];
        a.className = keyword
        a.addEventListener("click",populate)
        document.getElementsByClassName("dropdown-content")[0].appendChild(a);
    }
}
function populate(){
    en_keyword = this.className;
    document.getElementById("delete").disabled = false
    document.getElementsByClassName("dropbtn")[0].innerHTML = en_keyword;
    for (var lang in new_json){
        if (document.getElementById(lang.toUpperCase()) == null){
            continue
        }
        else{
            var a = document.createElement("a");
            a.innerHTML = lang
            a.addEventListener("click",updatePageSpecific)
            document.getElementsByClassName("dropdown-content")[1].appendChild(a)
            console.log(en_keyword)
            console.log(lang.toUpperCase())
            console.log(new_json)
            console.log(new_json[lang.toUpperCase()][en_keyword])
            document.getElementById(lang.toUpperCase()).value = new_json[lang.toUpperCase()][en_keyword];
        }
    }
    // chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
    //     chrome.tabs.sendMessage(tabs[0].id, {selection: 'test'}, function(response) {
    //         if (response == undefined){
    //             alert("Error, extension not able to communicate with webpage. Refresh and try again!");
    //         }
    //         else{
    //             let result = response.html; //html code from contentscript/stripo page
    //             // chrome.storage.local.set({'en':result}, function(){
    //             //     console.log("setting en in localstorage"); //set the en html into local storage for UNDO function
    //             // });
    //             // document.getElementById("undo").disabled=false; //enable undo for them
    //             var temp_replace = '<span style="background-color:#FFFF00; padding:5px">$&</span>'
    //             result = result.replace(new RegExp(new_json['EN'][en_keyword],"igs"),temp_replace);
    //             console.log(result);
    //             chrome.tabs.query({active: true, currentWindow: true}, async function(tabs) {
                    
    //                 chrome.tabs.sendMessage(tabs[0].id, {html: String(result), testing: true}, function(response) { //send message when button pressed
    //                     console.log(response.farewell);
    //                 });
    //             });   
    //         }
    //     });
    // });
}
function updatePageSpecific(){
    var lang = this.innerHTML;
    document.getElementsByClassName("dropbtn")[1].innerHTML = lang;
    document.getElementById("test").disabled=false;
    document.getElementById("update").disabled = false
    document.getElementById("test").addEventListener("click",function(){
        chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
            chrome.tabs.sendMessage(tabs[0].id, {selection: 'test'}, function(response) {
                if (response == undefined){
                    alert("Error, extension not able to communicate with webpage. Refresh and try again!");
                }
                else{
                    let result = response.html; //html code from contentscript/stripo page
                    // chrome.storage.local.set({'en':result}, function(){
                    //     console.log("setting en in localstorage"); //set the en html into local storage for UNDO function
                    // });
                    // document.getElementById("undo").disabled=false; //enable undo for them
                    var temp_replace = '<span style="background-color:#FFFF00; padding:5px">'+new_json[lang.toUpperCase()][en_keyword]+'</span>'
                    result = result.replace(new RegExp(new_json['EN'][en_keyword],"igs"),temp_replace);
                    console.log(result);
                    chrome.tabs.query({active: true, currentWindow: true}, async function(tabs) {
                        
                        chrome.tabs.sendMessage(tabs[0].id, {html: String(result), testing: true}, function(response) { //send message when button pressed
                            console.log(response.farewell);
                        });
                    });   
                }
            });
        });
    })
    
}
/* When the user clicks on the button,
toggle between hiding and showing the dropdown content */
function myFunction() {
    document.getElementById("myDropdown").classList.toggle("show");
}
function myFunction1() {
    document.getElementById("myDropdown1").classList.toggle("show");
}

async function updateJSON(){
    new_json = await chrome.storage.local.get(['json']); //await
    console.log(new_json);
    if (new_json['json']==undefined || new_json['json']=='undefined'){
        new_json = myJson //checks json is alr populated or not cleared
    }
    else{
        new_json = new_json['json']
    }
    for (var lang in new_json){
        if (document.getElementById(lang.toUpperCase()) != undefined){
            new_json[lang.toUpperCase()][document.getElementsByClassName("dropbtn")[0].innerHTML] = document.getElementById(lang.toUpperCase())
        }
    }
    chrome.storage.local.set({'json':new_json}, function(){
        console.log("setting");
        console.log(new_json);
    });
    chrome.storage.local.get(['json'],function(result){
        console.log(result['json']);
    });

    //show alert success (need to reload anot?)->nope
    alert("Success!");
}
async function deleteJSON(){
    new_json = await chrome.storage.local.get(['json']); //await
    console.log(new_json);
    if (new_json['json']==undefined || new_json['json']=='undefined'){
        new_json = myJson //checks json is alr populated or not cleared
    }
    else{
        new_json = new_json['json']
    }
    for (var lang in new_json){
        if (document.getElementById(lang.toUpperCase())!=undefined){
            delete new_json[lang][document.getElementsByClassName("dropbtn")[0].innerHTML]
        }
    }
}
// runtime
let new_json = {}
let en_keyword = ''
document.getElementsByClassName("dropbtn")[0].addEventListener("click",myFunction)
document.getElementsByClassName("dropbtn")[1].addEventListener("click",myFunction1)
document.getElementById("update").addEventListener("click",updateJSON)
document.getElementById("delete").addEventListener("click",deleteJSON)
// Close the dropdown menu if the user clicks outside of it
window.onclick = function(event) {
    if (!event.target.matches('.dropbtn')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
        var openDropdown = dropdowns[i];
        if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
        }
    }
    }
}
getJSON();