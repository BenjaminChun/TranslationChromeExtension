import myJson from './translations.json' assert {type: 'json'};


function addkeyword(){
    // key and value will be the same for en
    var en_keyword = document.getElementById("find-keyword").value

    var input_fields = document.getElementsByTagName("input");

    //insert en into json
    chrome.storage.local.get(['json'],function(r){ //need to account for new json
        let new_json = r['json'];
        console.log("in addkeyword")
        console.log(new_json)
        if(new_json == undefined || new_json=='undefined'){
            new_json = myJson
        }
        console.log(new_json['EN'][en_keyword])
        new_json['EN'][en_keyword] = en_keyword
        console.log(new_json)
        //insert other lang into json
        for (let index = 1; index < input_fields.length; index++) {
            new_json[input_fields[index].id.toUpperCase()][en_keyword] = input_fields[index].value
            console.log(new_json[input_fields[index].id.toUpperCase()][en_keyword])
        }
        //write back to json
        //BIG ISSUE, need a way to write back to JSON -> where is it stored?
        //write to local storage -> means that next read must be from local storage -> also means need to regulate
        chrome.storage.local.set({'json':new_json}, function(){
            console.log("setting");
            console.log(new_json);
        });
        chrome.storage.local.get(['json'],function(result){
            console.log(result['json']);
        });

        //show alert success (need to reload anot?)->nope
        alert("Success!");
    });
    
}
function checkAndEnableAdd(){
    var input_fields = document.getElementsByTagName("input");
    var non_empty_string = new RegExp("^\\S",'g');
    for (let index = 0; index < input_fields.length; index++) {
        if (input_fields[index].value.match(non_empty_string) == null){
            document.getElementById('add').disabled=true
            return false
        }
    }
    document.getElementById('add').disabled=false
    return true
}
function clearLocalStorage(){
    chrome.storage.local.set({'json':'undefined'}, function(){
        console.log("setting to undefined : json");
    });
    alert("Reseted to default JSON");
}
//run time
var input_fields = document.getElementsByTagName("input");
for (let index = 0; index < input_fields.length; index++) {
    input_fields[index].addEventListener("input",checkAndEnableAdd)
}
document.getElementById("add").addEventListener("click",addkeyword);
document.getElementById("reset").addEventListener('click',clearLocalStorage);