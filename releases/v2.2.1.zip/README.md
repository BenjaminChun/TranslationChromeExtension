# Chrome Extension for Mailer Translation in Stripo

## Description
It is a chrome extension that can be installed on any chrome device through developer tools. It allows users to translate stripo mailers <b>in-place<b> within the stripo website with just a few clicks. There is also a handy undo button that undos to the previous version of mailer, before the most recent translation.
It has a feature that allows users to add more keyword-replacements for translation on the local machine and immediately takes effect. Users also have the option to default back to their original json if they realised they messed up the translation json. 
![image for description](./images/extension.png "extension1")
![image for description](./images/extension2.png "extension2")
## Current Features
1. Translates on the Stripo page directly
    - Domain
    - Dollar
    - Common keywords
2. Improved usability with few clicks
3. Autosave function
4. Undo function
5. Continuous support from Benjamin =) from now till Dec 2022
    - new keywords and phrases to change
    - bug fixes and patches
    - changes to UI or content of popup

## Upcoming features
Check the issues tab to see the upcoming changes to the app and also contribute if you want.

- [ ] ~~Auto change name of document (v2)~~ - put on hold as it seems to be retrieving the name from somewhere else and js cant(?) simulate a click or a keypress
- [x] Adding new keywords to JSON (~~v3~~ v2)
- [ ] Improved distribution and autoupdate of extension (~~v4~~ v3) - easy solution seems to be putting on webstore and making it [private](https://cloud.google.com/blog/products/chrome-enterprise/publishing-extensions-for-the-enterprise) to domain 
- [ ] Implementing a framework (similar to a list of commands that abstracts away complicated low level code that might be very trivial eg. sort in python or java)